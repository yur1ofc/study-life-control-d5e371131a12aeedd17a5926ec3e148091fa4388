# O que mudou nesta atualização

## Arquivos incluídos (substitua/adicione por cima do projeto atual)
- `api/gemini.js` **(novo)** — função serverless que realmente existe e funciona no Vercel. Agora também exige login e limita 8 importações/dia por usuário (veja "Proteção contra abuso" abaixo).
- `grade-ia-import.js` **(reescrito)** — importação/atualização de grade com IA, com tela de comparação antes de salvar, e envia o login do usuário em cada chamada.
- `curriculum-catalog.js` **(editado)** — card "Catálogo comunitário" virou uma faixa fina e recolhível.
- `index.html` **(editado)** — adicionada a linha que carrega o `grade-ia-import.js` (antes ele nem rodava).
- `env-config.example.js` **(editado)** — só um comentário explicando onde a chave do Gemini deve ficar.
- `firestore.rules` **(editado)** — nova coleção `ai_usage` (regra `match /ai_usage/{userId}`) que guarda só o contador diário de cada usuário.

## Passo a passo para ativar (grátis, ~5 min)
1. Acesse https://aistudio.google.com/apikey, entre com sua conta Google e clique em "Create API key". É grátis, sem cartão.
2. No painel do Vercel do projeto → **Settings → Environment Variables** → adicione:
   - `GEMINI_API_KEY` → a chave que você copiou
   - Confirme que `FIREBASE_API_KEY` e `FIREBASE_PROJECT_ID` já existem ali (são as mesmas que o site já usa — precisam estar acessíveis também no lado do servidor, não só no build do front).
3. Publique o `firestore.rules` novo: `firebase deploy --only firestore:rules` (ou cole o conteúdo no console do Firebase → Firestore → Regras → Publicar).
4. Faça um novo deploy no Vercel para tudo valer.
5. Pronto: na Grade Curricular, o botão do topo agora é **"Atualizar com IA (PDF)"**.

## Proteção contra abuso (por que a chave não vai "acabar rapidão")
Antes, `/api/gemini` era uma URL pública sem trava nenhuma — qualquer script batendo nela direto consumiria sua cota do Gemini, sem nem passar pelo seu site. Agora:
- **Exige login**: o front manda o token do Firebase Auth do usuário logado; o servidor valida esse token antes de chamar o Gemini. Sem conta no seu app, não tem como chamar.
- **Limite diário por usuário**: cada pessoa logada só pode importar/atualizar a grade **8 vezes por dia** (dá pra ajustar em `DAILY_LIMIT` no topo de `api/gemini.js`). Isso é contado no Firestore, então nem um usuário legítimo consegue sozinho estourar a cota geral.

## Como usar para atualizar a grade
1. Clique em "Atualizar com IA (PDF)".
2. Envie o PDF (ou foto) da grade/fluxograma novo.
3. A IA lê o arquivo e o site mostra uma tela comparando: o que é novo, o que mudou (semestre, carga horária, obrigatória/optativa) e o que sumiu do arquivo novo.
4. Você decide o que remover (nada é apagado sozinho) e confirma. O que você já cursou/está cursando não é tocado — só a estrutura da grade é atualizada.
